# Example Python Code to Insert a Document 
#Trevin Wadlington

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password, host='localhost', port=27017, db='acc', col='animals'):
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        """
        Initialize MongoDB client connection.
        """
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'Trevon' 
        PASS = 'Always123' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        """
        Inserts a document in Mongo
        """
        if data is not None: 
            try:
                self.database.animals.insert_one(data)  # data should be dictionary
                return True
            except Exception as e:
                print("Error occured:", e)
                return False
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Create method to implement the R in CRUD.
    def read(self, query):
        
        try:
            if query is not None:
                data = list(self.database.animals.find(query))
            else:
                data = list(self.database.animals.find({}))
            return data
        except Exception as e:
            print("Error Occured:", e)
            return[]
        
    # Update
    def update(self, query, new_values):
        """
        update documents
        """
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print("Error", e)
                return 0
        else:
            raise exception("Both required.")
            
    # delete
    def delete(self, query):
        """
        delete entry
        """
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print("Error", e)
                return 0
        else:
            raise Exception("Query required.")