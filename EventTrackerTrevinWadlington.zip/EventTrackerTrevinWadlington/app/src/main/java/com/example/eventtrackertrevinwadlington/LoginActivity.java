package com.example.eventtrackertrevinwadlington;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ProgressBar;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtrackertrevinwadlington.DBHelper;
import com.example.eventtrackertrevinwadlington.EventDisplayActivity;
import com.example.eventtrackertrevinwadlington.R;

public class LoginActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private ProgressBar loadingProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Link the views from the XML layout
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login);
        loadingProgressBar = findViewById(R.id.loading);

        dbHelper = new DBHelper(this);

        // Enable the login button
        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkFields();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // login button click
        loginButton.setOnClickListener(v -> {
            loadingProgressBar.setVisibility(View.VISIBLE);

            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (dbHelper.checkUser(username, password)) {
                Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, EventDisplayActivity.class);
                startActivity(intent);
                finish();
            } else {
                boolean created = dbHelper.addUser(username, password);
                if (created) {
                    Toast.makeText(LoginActivity.this, "New user created!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, EventDisplayActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid credentials or user exists.", Toast.LENGTH_SHORT).show();
                }
            }

            loadingProgressBar.setVisibility(View.GONE);
        });
    }

    private void checkFields() {
        boolean isReady = !usernameEditText.getText().toString().trim().isEmpty()
                && !passwordEditText.getText().toString().trim().isEmpty();
        loginButton.setEnabled(isReady);
    }
}