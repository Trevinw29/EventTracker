package com.example.eventtrackertrevinwadlington;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.Toast;

public class EventDisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_event_display);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find the Add Event button
        Button addEventButton = findViewById(R.id.buttonAddEvent);

        // Handle button click
        addEventButton.setOnClickListener(v -> {
            // For now, just show a message
            Toast.makeText(EventDisplayActivity.this, "Add Event clicked!", Toast.LENGTH_SHORT).show();

            //Later, this can open a new AddEventActivity
            // Intent intent = new Intent(EventDisplayActivity.this, AddEventActivity.class);
            //startActivity(intent);
        });
    }
}